<?php

return [
    'credentials' => [
        'key'    => env('REKOGNITION_KEY_ID','AKIAIS5P2XMKEVJIBBSQ'),
        'secret' => env('REKOGNITION_SECRET_ACCESS_KEY','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'),
    ],
    'region' => 'us-east-1',
    'version' => 'latest'
];