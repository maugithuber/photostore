<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PhotographerController extends Controller
{
    //
}
