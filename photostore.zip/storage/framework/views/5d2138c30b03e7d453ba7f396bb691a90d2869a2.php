<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                
                    

                    
                        
                            
                                
                            
                        

                        
                    
             
                
                <img src="img/users/<?php echo e($user->photo); ?>" style="width:150px; height:150px; float:left;border-radius:50%; margin-right:25px" >
                <h2>    <?php echo e($user->name); ?>'s profile</h2>
                <form enctype="multipart/form-data" action="<?php echo e(url('profile')); ?>" method="POST">
                    <label>Updata Profile Image</label>
                    <input type="file" name="photo">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="submit"  class="pull-right btn btn-sm btn-primary">
                </form>

                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_pho', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>