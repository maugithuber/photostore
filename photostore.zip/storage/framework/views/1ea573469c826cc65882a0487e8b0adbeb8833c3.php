<?php $__env->startSection('title'); ?>
  Myphotos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="container-fluid">
        <div class="row">
            <h2 align="center"> <i class="fa fa-image" aria-hidden="true"></i> MY PHOTOS</h2>
            <h3 align="center"> <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></h3>
            <hr>
        </div>
    </div>

    <?php $__currentLoopData = $photos->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $photoChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-md-4">
                        <div class="thumbnail">
                            
                            <img src="<?php echo e(Image::make('img/photos/'.$photo->name)->resize(400,400)->encode('data-url')); ?>" >
                            
                            <div class="caption">
                                <div class="clearfix">
                                    <a href="<?php echo e(url('download'.$photo->id)); ?>" class="btn btn-primary pull-right" role="button">Download</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app_cli', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>