<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading" align="center">
                        <h2> EVENT INFO</h2>
                    </div>
                    <hr>

                    <div class="panel-body">

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Name:</label>
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e($event->name); ?>"disabled required autofocus >
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">Place:</label>
                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e($event->place); ?>"disabled required>
                            </div>
                        </div>


                        <div class="form-group">
                            <label  class="col-md-4 control-label">Date:</label>
                            <div class="col-md-6">
                                <input  id="phone" type="text"  name="phone"  value="<?php echo e($event->date); ?>" class="form-control" disabled required>
                            </div>
                        </div>
                        <div class="form-group" align="center">
                            <img  src="<?php echo e($event->qr); ?>" >
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_cli', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>