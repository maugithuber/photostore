<?php $__env->startSection('title'); ?>
    Event
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row">
            <h1 align="center"><?php echo e($event->name); ?></h1>
            <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <a href="#adicionar"  data-toggle="modal" type="button" class="btn btn-raised btn-danger  center-block ">Upload photo</a>
        </div>
    </div>

    <?php $__currentLoopData = $photos->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $photoChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-md-4">
                        <div class="thumbnail" align="center">
                            <img src="<?php echo e(Image::make('img/photos/'.$photo->name)->resize(400,400)->encode('data-url')); ?>" >                            <div class="caption">
                                <h3>$us. <?php echo e($photo->price); ?></h3>
                                <div class="clearfix">
                                    <a href="#edit"data-toggle="modal"  class="btn btn-warning btn-block" role="button">Edit</a>
                                </div>



                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="modal fade" id="adicionar">
        <form  class="form-vertical" action="<?php echo e(url('/store_photo'.$event->id)); ?>" role='form' method="POST" action="" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title"> Upload photo</h2>
                        <div class="form-group">
                            <div class="form-group">
                                <label>Photo: </label>
                                <input type="file" name="photo" required>
                            </div>
                            <label>Price: </label>
                            <input class="form-control" type="number" name="price" required autofocus>
                        </div>
                        <button class="btn btn-danger center-block">Save</button>
                    </div>
                </div>
            </div>
        </form>
    </div>





<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app_pho', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>