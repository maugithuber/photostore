<?php $__env->startSection('title'); ?>
    Event
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $photos->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $photoChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-md-4">
                            <div class="thumbnail">
                                <img src="<?php echo e($photo->url); ?>" >
                                
                                <div class="caption">
                                    <h3><?php echo e($photo->name); ?></h3>
                                    
                                    <div class="clearfix">
                                        <div class="pull-left price">$. <?php echo e($photo->price); ?></div>
                                        <a href="<?php echo e(url('add_cart'.$photo->id)); ?>" class="btn btn-success pull-right" role="button">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app_cli', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>