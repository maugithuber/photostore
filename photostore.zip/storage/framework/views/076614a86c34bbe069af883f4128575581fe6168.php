<?php $__env->startSection('title'); ?>
    Event
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>






    <?php if(Session::has('success')): ?>
        <div class="row">
            <div class="col-sm-6 col-md-4 col-md-offset-4 col-sm--offset-3">
                <div id="charge-message" class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>



    <a href="#adicionar"  data-toggle="modal" class="btn btn-warning btn-lg btn-block ">Upload photo</a>

    <?php $__currentLoopData = $photos->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photoChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $photoChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    
                        <div class="col-sm-6 col-md-4">
                            <div class="thumbnail">
                                <img src="img/photos/<?php echo e($photo->url); ?>" >
                                <div class="caption">
                                    <h3><?php echo e($photo->name); ?></h3>
                                    
                                    <div class="clearfix">
                                        <div class="pull-left price">Bs.<?php echo e($photo->price); ?></div>
                                        <a href="#" class="btn btn-success pull-right" role="button">Add to Cart</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




    <div class="modal fade" id="adicionar">
        <form  class="form-vertical" action="<?php echo e(url('/store_photo'.$event->id)); ?>" role='form' method="POST" action="" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title"> Upload photo</h2>
                        <div class="form-group">

                            <div class="form-group">
                                <label>Imagen: </label>
                                <input type="file"
                                       
                                       name="photo" required>

                            </div>

                            <label>Price: </label>
                            <input class="form-control" type="number" name="price" required autofocus>
                            <?php if($errors->has('name')): ?>
                                <span style="color: red;"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                        </div>


                        <button class="btn btn-success">Save</button>
                    </div>
                </div>
            </div>
        </form>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app_cli', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>