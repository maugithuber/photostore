<?php $__env->startSection('title'); ?>
    Client
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




    
    
    
    
    
    


    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="container-fluid">
                        <div class="row">
                            <h2 align="center"> <i class="fa fa-calendar" aria-hidden="true"></i> MY EVENTS</h2>
                            <a href="#adicionar"  data-toggle="modal" class="btn btn-warning btn-lg btn-block">Subscribe to an Event</a>
                            <hr>

                            
                            
                            
                            
                            
                            
                            
                        </div>
                    </div>
                    <div class="table-responsive" >
                        <table class="table table-hover" class="t">
                            <thead class="danger">
                            <tr class="danger">
                                <th >ID</th>
                                <th>Name</th>
                                <th>Place</th>
                                <th>Date</th>
                                
                                <th>QR code</th>
                                <th>Options</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="primary">
                                    <td><?php echo e($event->id); ?></td>
                                    <td><?php echo e($event->name); ?></td>
                                    <td><?php echo e($event->place); ?></td>
                                    <td><?php echo e($event->date); ?></td>
                                    <td>  <?php echo QrCode::size(100)->generate('Make me into a QrCode!'); ?></td>

                                    
                                    
                                    
                                    <td>
                                        
                                        
                                        <a href="<?php echo e(url('/events_cli'.$event->id)); ?>" class="btn btn-success "  role="button">View Photos</a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="adicionar">
        <form  class="form-vertical" action="<?php echo e(url('')); ?>" role='form' method="POST" action="" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title center-block"> Subscribe to an Event</h2>
                        <div class="form-group">
                            <label>Event Code: </label>
                            <input class="form-control" type="text" placeholder="type a code..." name="code" required autofocus>
                        </div>
                        <button class="btn btn-warning center-block">Save</button>
                    </div>
                </div>
            </div>
        </form>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_cli', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>