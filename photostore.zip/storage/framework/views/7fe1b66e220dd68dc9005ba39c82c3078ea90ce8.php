<?php $__env->startSection('title'); ?>
    My Cart
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('cart')): ?>
        
            
                
                    
                        
                            
                                
                                    
                                        
                                            
                                                
                                                
                                                    
                                                    
                                                    
                                                
                                                
                                                
                                                
                                                    
                                                        
                                                            
                                                        
                                                        
                                                        
                                                            
                                                                
                                                            
                                                        
                                                    
                                                
                                                
                                            
                                        
                                        
                                            
                                            
                                        
                                    
                                
                            
                        
                    
                
            
        

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="container-fluid">
                            <div class="row">
                                <h2 align="center"> <i class="fa fa-calendar" aria-hidden="true"></i> My Shopping Cart</h2>
                                <h4 align="center"> <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></h4>

                                
                                <hr>
                            </div>
                        </div>
                        <div class="table-responsive" >
                            <table class="table table-hover" class="t">
                                <thead class="danger">
                                <tr class="danger">
                                    <th><strong>Photo</strong></th>
                                    <th><strong>Price </strong></th>
                                    <th><strong>Option</strong></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="primary">
                                        <td>
                                            <img src="<?php echo e(Image::make('img/photos/'.$product['item']['name'])->resize(100,100)->encode('data-url')); ?>" >
                                            </td>
                                        <td> <?php echo e($product['price']); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('/remove'.$product['item']['id'] )); ?>" class="btn btn-danger btn-sm" role="button">
                                                <i class="fa fa-trash" aria-hidden="true"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
                            <h3>TOTAL :  <?php echo e($totalPrice); ?></h3><hr>
                            
                            
                            <a href="<?php echo e(route('payment')); ?>" class="btn btn-primary btn-block" role="button">
                               </i>CHECK OUT with PayPal
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    <?php else: ?>
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-heading" align="center">
                            <h2>Empty<i class="fa fa-shopping-cart" aria-hidden="true"></i></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_cli', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>