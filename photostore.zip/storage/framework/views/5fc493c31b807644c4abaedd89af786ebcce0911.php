<?php $__env->startSection('content'); ?>

    
        
            
                

                
                    
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    
                                        
                                    
                                
                            
                        

                        
                            
                                
                                    
                                

                                
                                    
                                
                            
                        
                    
                
            
        
    


<div class = "container">
    <div class="wrapper">
        <form name="Login_Form" class="form-signin"  method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo e(csrf_field()); ?>

            <h3 class="form-signin-heading">Welcome Back! Please Log In</h3>
            <hr class="colorgraph"><br>

            <input type="text" class="form-control"  id="email" name="email" placeholder="email" required="" autofocus="" />
            <input type="password" class="form-control" id ="password"name="password" placeholder="Password" required=""/>

            <button class="btn btn-lg btn-primary btn-block"  name="Submit" value="Login" type="Submit">Login</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>