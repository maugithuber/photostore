<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Email-Face</title>
</head>
<body>
<h1>A new photo where you appear is available!!</h1>
<h2>check it here <a href="http://localhost/photostore/public/">Photostore.com</a></h2>
</body>
</html>