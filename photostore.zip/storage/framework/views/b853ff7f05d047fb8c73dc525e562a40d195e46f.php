<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading" align="center"><h1><?php echo e($user->name); ?>'s profile<i class="fa fa-shopping-cart" aria-hidden="true"></i></h1>
                        <div class="panel-body">
                            <img src="img/users/<?php echo e($user->photo); ?>" style="width:150px; height:150px; float:left;border-radius:50%; margin-right:25px" >
                            
                            <form enctype="multipart/form-data" action="<?php echo e(url('profile')); ?>" method="POST">
                                <label>Update Profile Image</label>
                                <input type="file" name="photo">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="submit"  class="pull-right btn btn-sm btn-primary">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_cli', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>