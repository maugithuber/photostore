<?php $__env->startSection('title'); ?>
    Photographer
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




    
    
    
    
    
    


    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="container-fluid">
                        <div class="row">
                            <h2 align="center">MY CREATED EVENTS</h2>
                            <a href="#adicionar"  data-toggle="modal" class="btn btn-danger btn-lg btn-block">New Event</a>
                            <hr>

                            
                            
                            
                            
                            
                            
                            
                        </div>
                    </div>
                    <div class="table-responsive" >
                        <table class="table table-hover" class="t">
                            <thead class="danger">
                            <tr class="danger">
                                <th >ID</th>
                                <th>Name</th>
                                <th>Place</th>
                                <th>Date</th>
                                
                                <th>QR code</th>
                                <th>Options</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="primary">
                                    <td><?php echo e($event->id); ?></td>
                                    <td><?php echo e($event->name); ?></td>
                                    <td><?php echo e($event->place); ?></td>
                                    <td><?php echo e($event->date); ?></td>
                                    <td>  <?php echo QrCode::size(100)->generate('Make me into a QrCode!'); ?></td>

                                    
                                    
                                    
                                    <td>
                                        
                                        
                                        <a href="<?php echo e(url('/events_pho'.$event->id)); ?>" class="btn btn-primary "  role="button">Upload Photos</a>

                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="adicionar">
        <form  class="form-vertical" action="<?php echo e(url('/store_event')); ?>" role='form' method="POST" action="" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title"> Add event</h2>
                        <div class="form-group">
                            <label>Name: </label>
                            <input class="form-control" type="text" placeholder="type name..." name="name" required autofocus>
                            <?php if($errors->has('name')): ?>
                                <span style="color: red;"><?php echo e($errors->first('name')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Place: </label>
                            <input class="form-control" type="text" placeholder="type place..." name="place" required>
                            <?php if($errors->has('place')): ?>
                                <span style="color: red;"><?php echo e($errors->first('place')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>Date: </label>
                            <input class="form-control" type="date" name="date" required>
                            <?php if($errors->has('date')): ?>
                                <span style="color: red;"><?php echo e($errors->first('date')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>Type:</label>

                            <select name="type" class="form-control">
                                <option value="1">Public</option>
                                <option value="2" >Private</option>
                            </select>

                        </div>

                        <button class="btn btn-danger btn center-block">Save</button>
                    </div>
                </div>
            </div>
        </form>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_pho', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>