<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Email-Face</title>
</head>
<body>
<h1>Una foto en la que usted aparece esta disponible!!</h1>
<h2>Revisala aqui <a href="http://localhost/photostore/public/">Photostore.com</a></h2>
</body>
</html>